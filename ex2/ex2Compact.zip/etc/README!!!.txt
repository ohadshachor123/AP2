Since the full project is too large, I submitted only the source code, Without the external packages(Prism and Newtonsoft).
Obviously the code won't compile without installing these packages/ gathering the required dll files. 
 The full project, can be found here:
https://drive.google.com/file/d/1ezMJRaM8cZ7znhC0NuglKJ-XA8gyHqjA/view?usp=sharing