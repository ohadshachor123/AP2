﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ImageService.Logging
{
    public enum MessageType : int
    {
        INFO,
        FAIL,
        WARNING,
    }
}
